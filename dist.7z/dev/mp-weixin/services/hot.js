"use strict";
const utils_http = require("../utils/http.js");
const getHotRecommemdAPI = (url, data) => {
  return utils_http.http({
    method: "GET",
    url,
    data
  });
};
exports.getHotRecommemdAPI = getHotRecommemdAPI;
//# sourceMappingURL=hot.js.map
