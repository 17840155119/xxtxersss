"use strict";
const _imports_0 = "/static/images/logo.png";
exports._imports_0 = _imports_0;
//# sourceMappingURL=assets.js.map
