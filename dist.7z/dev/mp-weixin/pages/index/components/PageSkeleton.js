"use strict";
const common_vendor = require("../../../common/vendor.js");
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  return {};
}
const Component = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "D:/小程序/uniapp-shop/src/pages/index/components/PageSkeleton.vue"]]);
wx.createComponent(Component);
//# sourceMappingURL=PageSkeleton.js.map
